# ESP32 NimBLE Keyboard library

Changed the original [ESP32-BLE-Keyboard](https://github.com/T-vK/ESP32-BLE-Keyboard) to support NimBLE.

This library allows you to make the ESP32 act as a Bluetooth Keyboard and control what it does.  
You might also be interested in:
- [ESP32-NimBLE-Mouse](https://github.com/wakwak-koba/ESP32-NimBLE-Mouse)
- [ESP32-NimBLE-Gamepad](https://github.com/lemmingDev/ESP32-BLE-Gamepad)
